package com.Tsai.final_06156157;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.SimpleCursorAdapter;

import java.util.Calendar;

public class AddActivity extends AppCompatActivity {
    private EditText edDate;
    private EditText editem;
    private EditText edAmount;
    Calendar calendar = Calendar.getInstance();
    private Sql helper;
    int dateId = 2;

    private Button btDate;
    private Button btTime;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.finance);
        findViews();
        helper = new Sql(this, "expense.db", null, 1);

        btDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                final int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePicker = new DatePickerDialog(AddActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        edDate.setText(year+"/"+month+"/"+day);
                    }
                },2019,6,5);
                datePicker.show();

            }
        });

    }

    public void add(View view){
        //String cdate = edDate.getText().toString();
        //String editem = editem.getText().toString();
        //int amount = Integer.parseInt( edAmount.getText().toString());
        ContentValues values = new ContentValues();
        values.put("date", edDate.getText().toString());
        values.put("info",  editem.getText().toString());
        values.put("amount",  Integer.parseInt( edAmount.getText().toString()));
        long id = helper.getWritableDatabase().insert("exp", null, values);
        Cursor c = helper.getReadableDatabase().query(
                "exp", null, null, null, null, null, null);
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,R.layout.aaaa,  c, new String[] {"date","info", "amount"}, new int[] {R.id.a1, R.id.a2,R.id.a3}, 0);
        MainActivity.list.setAdapter(adapter);
        c.requery();

        Log.d("ADD", id + "");
    }

    private void findViews() {
        btDate = findViewById(R.id.btDate);
        edDate = findViewById(R.id.edDate);
        editem = findViewById(R.id.editem);
        edAmount = findViewById(R.id.edAmount);

    }
}


