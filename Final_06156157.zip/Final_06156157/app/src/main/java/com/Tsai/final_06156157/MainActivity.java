package com.Tsai.final_06156157;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Sql helper;
    private SimpleCursorAdapter adapter;
    static ListView list;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
                Intent intent = new Intent(MainActivity.this, AddActivity.class);
                startActivity(intent);
            }
        });
        list = (ListView) findViewById(R.id.list);


        helper = new Sql(this, "expense.db", null, 1);

        //方法1
        // select * from table where x = '5'     x = ?
        final Cursor c = helper.getReadableDatabase().query(
                "exp", null, null, null, null, null, null);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, final long id) {
                c.requery();
                c.moveToPosition(position);
                AlertDialog.Builder blog=new AlertDialog.Builder(MainActivity.this);
                blog.setMessage("日期 : "+c.getString(c.getColumnIndex("date"))+"\n項目: "
                        +c.getString(c.getColumnIndex("info"))+"\n金額: ");

                blog.setView(R.layout.blogv);
                final EditText blogtext = (EditText)findViewById(R.id.blogtext);
                blog.setNegativeButton("修改", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //if(!blogtext.getText().toString().equals("")){
                            ContentValues values = new ContentValues();
                            values.put("amount", blogtext.getText().toString());
                            helper.getWritableDatabase().update("exp",values,"_id="+id,null);
                            c.requery();
                            SimpleCursorAdapter adapter = new SimpleCursorAdapter(MainActivity.this,R.layout.aaaa,c, new String[]{"date", "info","amount"}, new int[]{R.id.a1, R.id.a2,R.id.a3}, 0);
                            list.setAdapter(adapter);
                        //}
                    }
                });
                blog.setPositiveButton("刪除", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        helper.getWritableDatabase().delete("exp","_id="+c.getInt(0),null);
                        c.requery();
                        SimpleCursorAdapter adapter = new SimpleCursorAdapter(MainActivity.this,R.layout.aaaa,c, new String[]{"date", "info","amount"}, new int[]{R.id.a1, R.id.a2,R.id.a3}, 0);
                        list.setAdapter(adapter);
                    }
                });
                blog.setNeutralButton("返回", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                blog.show();

            }
        });
        //方法2
//        Cursor cursor = helper.getReadableDatabase().rawQuery(
//                "SELECT _ID, cdate, info FROM exp ", null);
        //Context context, int layout, Cursor c, String[] from, int[] to, int flags
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,R.layout.aaaa,  c, new String[] {"date","info", "amount"}, new int[] {R.id.a1, R.id.a2,R.id.a3}, 0);

        list.setAdapter(adapter);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
